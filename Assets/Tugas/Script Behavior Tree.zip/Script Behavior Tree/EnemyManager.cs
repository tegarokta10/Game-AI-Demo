using UnityEngine;

public class EnemyManager : MonoBehaviour
{
    // Variabel private untuk menyimpan jumlah health points (nyawa) dari musuh.
    private int _healthpoints;

    // Fungsi Awake() dipanggil ketika object musuh pertama kali dibuat atau diinisialisasi.
    // Inisialisasi health points musuh menjadi 30.
    private void Awake()
    {
         Debug.Log("EnemyManager initialized.");
        _healthpoints = 40;  // Health points awal musuh.
    }

    // Fungsi untuk mengurangi health points musuh ketika terkena serangan.
    // Mengembalikan nilai true jika musuh mati, atau false jika masih hidup.
    public bool TakeHit()
    {
        // Mengurangi health points sebesar 10 setiap kali musuh terkena serangan.
        _healthpoints -= 10;

        // Cek apakah health points sudah habis atau kurang dari 0 (musuh mati).
        bool isDead = _healthpoints <= 0;

        // Jika musuh mati (health points habis), panggil fungsi _Die() untuk menghancurkan object musuh.
        if (isDead) _Die();

        // Kembalikan status apakah musuh sudah mati atau belum.
        return isDead;
    }

    // Fungsi private untuk memproses kematian musuh dengan cara menghancurkan game object-nya.
    private void _Die()
    {
        Destroy(gameObject);  // Menghancurkan object musuh dari game.
    }
}
