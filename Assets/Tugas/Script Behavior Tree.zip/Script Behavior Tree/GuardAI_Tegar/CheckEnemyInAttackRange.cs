using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using BehaviorTree;

public class CheckEnemyInAttackRange : Node
{
    // Variabel Transform untuk menyimpan posisi NPC.
    private Transform _transform;

    // Animator digunakan untuk mengontrol animasi NPC.
    private Animator _animator;

    // Constructor yang menerima transform NPC untuk menentukan posisi dan animasi.
    public CheckEnemyInAttackRange(Transform transform)
    {
        _transform = transform;  // Inisialisasi posisi NPC.
        _animator = transform.GetComponent<Animator>();  // Mengambil komponen Animator dari NPC.
    }

    // Override metode Evaluate() yang akan menjalankan logika untuk memeriksa apakah musuh berada dalam jarak serang (attack range).
    public override NodeState Evaluate()
    {
        // Mengambil data target dari Behavior Tree yang sudah disimpan sebelumnya (biasanya oleh node CheckEnemyInFOVRange).
        object t = GetData("target");

        // Jika tidak ada target (belum disimpan oleh node lain), node mengembalikan FAILURE.
        if (t == null)
        {
            state = NodeState.FAILURE;
            return state;
        }

        // Mengonversi objek target yang diambil menjadi Transform untuk mendapatkan posisi musuh.
        Transform target = (Transform)t;

        // Jika jarak antara NPC dan target lebih kecil atau sama dengan jarak serang yang ditentukan (GuardBT.attackRange), NPC mulai menyerang.
        if (Vector3.Distance(_transform.position, target.position) <= GuardBT.attackRange)
        {   
            // Mengatur animasi NPC untuk mulai menyerang dan menghentikan animasi berjalan.
            _animator.SetBool("Attacking", true);
            _animator.SetBool("Walking", false);

            // Mengembalikan SUCCESS karena musuh berada dalam jarak serang dan NPC siap menyerang.
            state = NodeState.SUCCESS;
            return state;
        }
        // Jika musuh tidak berada dalam jarak serang, node mengembalikan FAILURE.
        state = NodeState.FAILURE;
        return state;
    }

}
