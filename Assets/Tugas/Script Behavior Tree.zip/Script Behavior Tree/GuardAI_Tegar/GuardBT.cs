using System.Collections.Generic;
using BehaviorTree;

public class GuardBT : Tree
{
    // Array waypoints yang akan digunakan oleh NPC untuk menentukan titik-titik patroli.
    public UnityEngine.Transform[] waypoints;

    // Beberapa variabel statis yang mengatur kecepatan gerak NPC, jarak pandang (field of view), dan jarak serang.
    public static float speed = 1f;       // Kecepatan bergerak NPC.
    public static float fovRange = 3f;    // Jarak pandang NPC untuk mendeteksi musuh.
    public static float attackRange = 0.5f; // Jarak di mana NPC dapat menyerang musuh.

    // Implementasi dari metode abstract SetupTree() dari kelas Tree.
    // Metode ini digunakan untuk membangun dan mengatur struktur Behavior Tree NPC.
    protected override Node SetupTree()
    {
        // Root dari Behavior Tree adalah Selector, yang akan mencoba node-node child dalam urutan sampai satu berhasil.
        Node root = new Selector(new List<Node>
        {
            // Bagian ini dikomentari, namun seharusnya mengecek apakah musuh berada dalam jarak serang,
            // Jika iya, NPC akan menyerang musuh.
                new Sequence(new List<Node>
            {
                new CheckEnemyInAttackRange(transform),
                new TaskAttack(transform),
           }),

            // Sequence yang pertama mengecek apakah musuh berada dalam jarak pandang (field of view).
            // Jika musuh terlihat, NPC akan bergerak mendekati target.
            new Sequence(new List<Node>
            {
                new CheckEnemyInFOVRange(transform),  // Cek apakah musuh ada di jarak pandang.
                new TaskGoToTarget(transform),        // Jika ada, pergi ke target musuh.
            }),

            // Jika tidak ada musuh dalam jarak pandang, NPC akan berpatroli di antara waypoints.
            new TaskPatrol(transform, waypoints),   // Patroli jika tidak ada musuh yang terlihat.
        });

        // Mengembalikan node root dari Behavior Tree.
        return root;
    }
}
