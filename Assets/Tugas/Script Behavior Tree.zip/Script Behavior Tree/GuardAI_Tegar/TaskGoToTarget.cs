using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using BehaviorTree;

public class TaskGoToTarget : Node
{
    // Variabel Transform untuk menyimpan posisi NPC.
    private Transform _transform;

    // Constructor yang mengambil parameter transform dari NPC yang akan bergerak menuju target.
    public TaskGoToTarget(Transform transform)
    {
        _transform = transform;  // Inisialisasi posisi NPC.
    }

    // Override metode Evaluate() yang dipanggil untuk menjalankan logika node ini.
    public override NodeState Evaluate()
    {
        // Mengambil data "target" yang disimpan sebelumnya dari Behavior Tree.
        Transform target = (Transform)GetData("target");

        // Jika jarak antara NPC dan target lebih besar dari nilai threshold (0.01f), NPC akan bergerak ke target.
        if (Vector3.Distance(_transform.position, target.position) > 0.3f)
        {
            // Menggerakkan NPC menuju target dengan kecepatan tertentu yang diatur oleh GuardBT.speed.
            _transform.position = Vector3.MoveTowards(
                _transform.position, target.position, GuardBT.speed * Time.deltaTime);

            // NPC menghadap ke arah target.
            _transform.LookAt(target.position);
        }

        // Mengembalikan status RUNNING karena NPC masih dalam proses bergerak ke target.
        state = NodeState.RUNNING;
        return state;
    }
}
