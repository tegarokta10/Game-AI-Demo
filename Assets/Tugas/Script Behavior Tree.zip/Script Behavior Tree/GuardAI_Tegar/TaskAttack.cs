using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using BehaviorTree;

public class TaskAttack : Node
{
    // Variabel untuk menyimpan komponen Animator dari NPC, digunakan untuk mengontrol animasi serangan.
    private Animator _animator;

    // Variabel untuk menyimpan referensi target terakhir (musuh) yang sedang diserang.
    private Transform _lastTarget;

    // Variabel untuk mengakses EnemyManager dari target (musuh), yang mengelola health points musuh.
    private EnemyManager _enemyManager;

    // Durasi waktu serangan dalam detik.
    private float _attackTime = 1f;

    // Counter untuk menghitung waktu sejak serangan terakhir.
    private float _attackCounter = 0f;

    // Constructor yang menerima Transform NPC untuk mendapatkan komponen Animator.
    public TaskAttack(Transform transform)
    {
        _animator = transform.GetComponent<Animator>();  // Mengambil komponen Animator dari NPC.
    }

    // Override metode Evaluate() untuk menjalankan logika serangan pada target.
    public override NodeState Evaluate()
    {
        // Mengambil data "target" dari Behavior Tree, yaitu musuh yang akan diserang.
        Transform target = (Transform)GetData("target");

        // Jika target baru (berbeda dari target sebelumnya), ambil EnemyManager dari target dan simpan target baru.
        if (target != _lastTarget)
        {
                
            _enemyManager = target.GetComponent<EnemyManager>();  // Mendapatkan EnemyManager dari musuh.
            Debug.Log(_enemyManager != null ? "EnemyManager found!" : "EnemyManager not found!");
            _lastTarget = target;  // Menyimpan referensi target terbaru.
        }

        // Menambahkan waktu ke counter untuk menghitung waktu yang berlalu sejak serangan terakhir.
        _attackCounter += Time.deltaTime;

        // Jika waktu yang telah berlalu sudah lebih dari atau sama dengan durasi serangan (1 detik).
        if (_attackCounter >= _attackTime)
        {
            // Panggil fungsi TakeHit() dari EnemyManager untuk menyerang musuh.
            bool enemyIsDead = _enemyManager.TakeHit();

            // Jika musuh mati (nyawa musuh habis).
            if (enemyIsDead)
            {
                ClearData("target");  // Hapus data target dari Behavior Tree.

                // Ubah animasi NPC   menjadi berhenti menyerang dan kembali berjalan.
                _animator.SetBool("Attacking", false);
                _animator.SetBool("Walking", true);
            }
            else
            {
                // Reset attack counter jika musuh belum mati dan serangan harus dilakukan lagi setelah 1 detik.
                _attackCounter = 0f;
            }
        }

        // Kembalikan status RUNNING karena NPC masih dalam proses menyerang target.
        state = NodeState.RUNNING;
        return state;
    }

}
