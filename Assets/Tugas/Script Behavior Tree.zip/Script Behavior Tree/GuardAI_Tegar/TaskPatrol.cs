using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using BehaviorTree;

public class TaskPatrol : Node
{
    // Transform untuk posisi NPC atau objek.
    private Transform _transform;

    // Animator digunakan untuk mengontrol animasi NPC, seperti transisi dari idle ke berjalan.
    private Animator _animator;

    // Array dari waypoint yang digunakan untuk menentukan rute patroli.
    private Transform[] _waypoints;

    // Indeks waypoint saat ini yang dituju oleh NPC.
    private int _currentWaypointIndex = 0;

    // Waktu tunggu di setiap waypoint, dalam detik.
    private float _waitTime = 1f; // dalam detik

    // Counter untuk melacak waktu tunggu saat berada di waypoint.
    private float _waitCounter = 0f;

    // Flag untuk menandai apakah NPC sedang menunggu di waypoint atau tidak.
    private bool _waiting = false;

    // Constructor untuk TaskPatrol, mengambil transform NPC dan array waypoint.
    public TaskPatrol(Transform transform, Transform[] waypoints)
    {
        _transform = transform;  // Mengambil posisi NPC.
        _animator = transform.GetComponent<Animator>();  // Mengambil komponen Animator untuk NPC.
        _waypoints = waypoints;  // Mendapatkan daftar waypoint.
    }

    // Metode Evaluate() untuk menjalankan logika patroli NPC. Di-override dari kelas Node.
    public override NodeState Evaluate()
    {
        // Jika NPC sedang menunggu di waypoint.
        if (_waiting)
        {
            // Hitung waktu yang telah dihabiskan NPC di waypoint.
            _waitCounter += Time.deltaTime;

            // Jika waktu menunggu sudah selesai, lanjutkan patroli.
            if (_waitCounter >= _waitTime)
            {
                _waiting = false;  // Mengakhiri status menunggu.
                _animator.SetBool("Walking", true);  // Mengubah animasi menjadi berjalan.
            }
        }
        else
        {
            // Mendapatkan waypoint yang sedang dituju.
            Transform wp = _waypoints[_currentWaypointIndex];

            // Jika NPC sudah mencapai waypoint (jaraknya sangat dekat).
            if (Vector3.Distance(_transform.position, wp.position) < 0.5f)
            {
                // Set posisi NPC ke waypoint saat ini.
                _transform.position = wp.position;

                // Reset counter waktu tunggu.
                _waitCounter = 0f;

                // NPC mulai menunggu di waypoint.
                _waiting = true;

                // Ganti waypoint berikutnya yang akan dituju (dengan sirkulasi menggunakan modulus).
                _currentWaypointIndex = (_currentWaypointIndex + 1) % _waypoints.Length;

                // Ubah animasi menjadi idle (berhenti berjalan).
                _animator.SetBool("Walking", false);
            }
            else
            {
                // Jika belum mencapai waypoint, NPC bergerak menuju waypoint.
                _transform.position = Vector3.MoveTowards(_transform.position, wp.position, GuardBT.speed * Time.deltaTime);

                // NPC menghadap ke arah waypoint yang dituju.
                _transform.LookAt(wp.position);
            }
        }

        // Status node tetap RUNNING selama NPC masih dalam patroli.
        state = NodeState.RUNNING;
        return state;
    }

}
