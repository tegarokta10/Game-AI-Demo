using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using BehaviorTree;

public class CheckEnemyInFOVRange : Node
{
    // Variabel untuk menyimpan layer mask yang hanya akan mendeteksi objek yang berada di layer "Enemy" (dalam hal ini layer 6).
    private static int _enemyLayerMask = 1 << 3;

    // Transform untuk posisi NPC.
    private Transform _transform;

    // Animator untuk mengontrol animasi NPC.
    private Animator _animator;

    // Constructor untuk inisialisasi _transform dan _animator.
    public CheckEnemyInFOVRange(Transform transform)
    {
        _transform = transform;  // Menyimpan transform NPC (posisi NPC).
        _animator = transform.GetComponent<Animator>();  // Mengambil komponen Animator dari NPC.
    }

    // Metode untuk mengevaluasi apakah ada musuh dalam jarak pandang (FOV - Field of View) NPC.
    public override NodeState Evaluate()
    {
        // Memeriksa apakah sudah ada target yang tersimpan di data tree.
        object t = GetData("target");

        // Jika belum ada target (null), lakukan pencarian musuh di sekitar NPC.
        if (t == null)
        {
            // Gunakan OverlapSphere untuk mendeteksi musuh di sekitar NPC dalam radius tertentu (fovRange) dengan layer mask yang hanya mendeteksi musuh.
            Collider[] colliders = Physics.OverlapSphere(
                _transform.position, GuardBT.fovRange, _enemyLayerMask);

            // Jika ada musuh terdeteksi.
            if (colliders.Length > 0)
            {
                // Simpan musuh pertama yang terdeteksi ke dalam data tree sebagai "target".
                parent.parent.SetData("target", colliders[0].transform);

                // Set animasi berjalan (NPC mulai bergerak menuju target).
                _animator.SetBool("Walking", true);

                // Mengembalikan SUCCESS, karena musuh berhasil terdeteksi.
                state = NodeState.SUCCESS;
                return state;
            }

            // Jika tidak ada musuh dalam jarak pandang, node mengembalikan FAILURE.
            state = NodeState.FAILURE;
            return state;
        }

        // Jika sudah ada target yang tersimpan, node tetap mengembalikan SUCCESS.
        state = NodeState.SUCCESS;
        return state;
    }

}
