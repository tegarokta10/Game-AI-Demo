using System.Collections.Generic;

namespace BehaviorTree
{
    // Sequence adalah node komposit dalam Behavior Tree yang menjalankan child node-nya secara berurutan.
    public class Sequence : Node
    {
        // Constructor default untuk Sequence tanpa child node.
        public Sequence() : base() { }

        // Constructor yang menerima list of child nodes untuk dihubungkan ke Sequence.
        public Sequence(List<Node> children) : base(children) { }

        // Override dari fungsi Evaluate() untuk mengevaluasi child nodes secara berurutan.
        public override NodeState Evaluate()
        {
            // Flag untuk melacak apakah ada child node yang masih dalam status RUNNING.
            bool anyChildIsRunning = false;

            // Loop melalui semua child node di Sequence.
            foreach (Node node in children)
            {
                // Evaluasi child node dan tentukan tindakan berdasarkan hasil evaluasi.
                switch (node.Evaluate())
                {
                    // Jika ada child node yang gagal, seluruh Sequence dianggap gagal (FAILURE).
                    case NodeState.FAILURE:
                        state = NodeState.FAILURE;
                        return state;  // Mengembalikan status kegagalan.

                    // Jika child node berhasil, lanjutkan ke child node berikutnya.
                    case NodeState.SUCCESS:
                        continue;  // Lanjutkan ke iterasi berikutnya.

                    // Jika child node masih berjalan (RUNNING), tandai bahwa Sequence sedang dalam proses.
                    case NodeState.RUNNING:
                        anyChildIsRunning = true;  // Set flag bahwa ada node yang sedang berjalan.
                        continue;  // Lanjutkan ke iterasi berikutnya.

                    // Default case, seharusnya tidak akan terjadi tetapi disiapkan untuk keamanan.
                    default:
                        state = NodeState.SUCCESS;
                        return state;
                }
            }

            // Setelah semua child dievaluasi, tentukan state dari Sequence secara keseluruhan.
            // Jika ada child yang masih RUNNING, Sequence tetap RUNNING, jika tidak, Sequence dianggap SUCCESS.
            state = anyChildIsRunning ? NodeState.RUNNING : NodeState.SUCCESS;
            return state;  // Mengembalikan status akhir Sequence.
        }

    }

}
