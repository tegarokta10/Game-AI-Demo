using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BehaviorTree
{
    // Dasar untuk pohon perilaku (Behavior Tree) dalam Unity.
    public abstract class Tree : MonoBehaviour
    {   
        // Root node dari Behavior Tree, mewakili node utama dalam Behavior Tree.
        private Node _root = null;

        // Fungsi Start() dipanggil sekali saat game dimulai atau saat GameObject diaktifkan.
        // Di sini, root node dari Behavior Tree diinisialisasi dengan memanggil SetupTree().
        protected void Start()
        {
            _root = SetupTree();  // Set root node menggunakan SetupTree() yang akan diimplementasikan di turunan kelas.
        }

        // Fungsi Update() dipanggil pada setiap frame. 
        // Fungsi ini memastikan Behavior Tree dievaluasi secara terus menerus selama game berjalan.
        private void Update()
        {
            if (_root != null)  // Jika root node ada (tidak null), evaluasi Behavior Tree.
                _root.Evaluate();  // Evaluasi kondisi root node.
        }

        // SetupTree() adalah metode abstract yang akan didefinisikan di subclass.
        // Tujuannya adalah untuk memberikan struktur Behavior Tree, mengatur node root dan node-node lainnya.
        protected abstract Node SetupTree();
    }
}
