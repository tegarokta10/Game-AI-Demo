using System.Collections.Generic;

namespace BehaviorTree
{
    // Selector adalah node komposit dalam Behavior Tree yang menjalankan child node-nya satu per satu hingga salah satu berhasil (SUCCESS).
    public class Selector : Node
    {
        // Constructor default untuk Selector tanpa child node.
        public Selector() : base() { }

        // Constructor yang menerima list of child nodes untuk dihubungkan ke Selector.
        public Selector(List<Node> children) : base(children) { }

        // Override dari metode Evaluate() untuk mengevaluasi child nodes satu per satu hingga salah satu berhasil.
        public override NodeState Evaluate()
        {
            // Loop melalui semua child node yang terhubung ke Selector.
            foreach (Node node in children)
            {
                // Evaluasi child node dan ambil tindakan berdasarkan hasil evaluasi.
                switch (node.Evaluate())
                {
                    // Jika child node gagal (FAILURE), lanjutkan ke child node berikutnya.
                    case NodeState.FAILURE:
                        continue;

                    // Jika child node berhasil (SUCCESS), Selector juga berhasil.
                    case NodeState.SUCCESS:
                        state = NodeState.SUCCESS;
                        return state;  // Return SUCCESS jika salah satu child node berhasil.

                    // Jika child node masih RUNNING, maka Selector tetap RUNNING.
                    case NodeState.RUNNING:
                        state = NodeState.RUNNING;
                        return state;  // Return RUNNING jika salah satu child node masih berjalan.

                    // Default case, jika tidak ada kondisi lain, lanjutkan.
                    default:
                        continue;
                }
            }

            // Jika tidak ada child node yang berhasil, maka Selector mengembalikan FAILURE.
            state = NodeState.FAILURE;
            return state;
        }

    }

}
