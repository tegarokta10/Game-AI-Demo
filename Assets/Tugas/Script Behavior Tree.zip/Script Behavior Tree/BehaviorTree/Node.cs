using System.Collections;
using System.Collections.Generic;

namespace BehaviorTree
{
    // Enum untuk mendefinisikan status node dalam Behavior Tree.
    public enum NodeState
    {
        RUNNING,  // Node masih diproses.
        SUCCESS,  // Node berhasil menyelesaikan tugas.
        FAILURE   // Node gagal menyelesaikan tugas.
    }

    // Kelas dasar Node untuk digunakan dalam Behavior Tree.
    public class Node
    {
        // Menyimpan status node saat ini.
        protected NodeState state;

        // Menyimpan referensi ke parent node (node induk) dari node saat ini.
        public Node parent;

        // List untuk menyimpan child nodes (node anak) yang terhubung dengan node saat ini.
        protected List<Node> children = new List<Node>();

        // Dictionary untuk menyimpan konteks data dari node.
        private Dictionary<string, object> _dataContext = new Dictionary<string, object>();

        // Constructor default, inisialisasi parent sebagai null.
        public Node()
        {
            parent = null;
        }

        // Constructor untuk membuat node dengan beberapa child.
        public Node(List<Node> children)
        {
            foreach (Node child in children)
                _Attach(child);  // Melampirkan setiap child node ke node saat ini.
        }

        // Metode private untuk mengatur parent dari node anak dan menambahkannya ke list children.
        private void _Attach(Node node)
        {
            node.parent = this;  // Menetapkan node induk.
            children.Add(node);   // Menambahkan node anak ke list children.
        }

        // Fungsi Evaluate untuk mengevaluasi node. Ini virtual, jadi bisa di-override oleh subclass.
        // Default-nya, node mengembalikan FAILURE, berarti node tidak melakukan apa-apa.
        public virtual NodeState Evaluate() => NodeState.FAILURE;

        // Metode untuk menyimpan data dengan pasangan key-value di dalam node.
        public void SetData(string key, object value)
        {
            _dataContext[key] = value;  // Menyimpan data dalam dictionary.
        }

        // Metode untuk mengambil data dari node berdasarkan key.
        public object GetData(string key)
        {
            object value = null;
            // Mencoba mengambil value dari dictionary.
            if (_dataContext.TryGetValue(key, out value))
                return value;

            // Jika key tidak ditemukan di node saat ini, coba cari di parent node.
            Node node = parent;
            while (node != null)
            {
                value = node.GetData(key);
                if (value != null)
                    return value;
                node = node.parent;
            }
            return null;  // Jika key tidak ditemukan, return null.
        }

        // Metode untuk menghapus data dari node atau parent node berdasarkan key.
        public bool ClearData(string key)
        {
            // Cek apakah key ada di node saat ini.
            if (_dataContext.ContainsKey(key))
            {
                _dataContext.Remove(key);  // Hapus data jika ditemukan.
                return true;
            }

            // Jika tidak ada, coba hapus di parent node.
            Node node = parent;
            while (node != null)
            {
                bool cleared = node.ClearData(key);
                if (cleared)
                    return true;
                node = node.parent;
            }
            return false;  // Return false jika key tidak ditemukan di node manapun.
        }
    }

}
